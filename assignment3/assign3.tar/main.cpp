#include <iostream>
#include <string>
#include "animal.h"
#include "monkey.h"
#include "meerkat.h"
#include "seaotter.h"
#include "zoo.h"
#include "main.h"



/*********************************************************************
 * ** Program: main.cpp
 * ** Description: calls the zoo class to execute
 * ** Pre-Conditions: all other classes made
 * ** Post-Conditions: zootycoon program run
 * *********************************************************************/ 


int main(){
	Zoo main_zoo;

	main_zoo.week();

	return 0;

}

