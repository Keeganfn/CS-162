#ifndef SEAOTTER_H
#define SEAOTTER_H



/*********************************************************************
 * ** Program:seaotter.h
 * ** Description: Header file for the seaotter class
 * ** Pre-Conditions: NA
 * ** Post-Conditions: helps initialize seaotter class
 * *********************************************************************/ 

#include <iostream>
#include <string>
#include "animal.h"

using namespace std;

class Seaotter: public Animal{
        public:
        Seaotter();
};


#endif


