#ifndef MAIN_H
#define MAIN_H


/*********************************************************************
 * ** Program:main.h
 * ** Description:header file for main
 * ** Pre-Conditions:NA
 * ** Post-Conditions:NA
 * *********************************************************************/ 
#include <iostream>
#include <string>

using namespace std;

int int_check(string, char, char);

#endif
