Name: Keegan Nave

Description: This program creates a linked list class with all of the required functionality, it also has 
	     ascending and descending sorting. Main contains the sample code that we were supposed to implement.

Notes: (1) I did not do any input checking for my main() implementation program as it was not a requirment listed.
	   So it assumes you are entering integers only.
	
       (2) My insert() function in my Linked_List runs on the assumption that the index of the list starts at 0.

       (3) I use Merge sort for both of my sorting functions. The number of primes is printed out after
	   calling either one, the function is private and is called get_prime().

       (4) None of my functions automatially print out the list, so you will need to call print() after any operation
	   you wish to see change the list.

       (4) I did not do any of the extra credit.
        
       Thanks!
